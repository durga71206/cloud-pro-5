import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";

const firebaseConfig = {
  apiKey: "AIzaSyCBfkffnMQTSFNX50NWem9H7yeQBDsYoZI",
  authDomain: "student-notes-cloud-fc316.firebaseapp.com",
  projectId: "student-notes-cloud-fc316",
  storageBucket: "student-notes-cloud-fc316.firebasestorage.app",
  messagingSenderId: "936660545927",
  appId: "1:936660545927:web:ed6631f415302caf942322"
};

const app = initializeApp(firebaseConfig);

export default app;