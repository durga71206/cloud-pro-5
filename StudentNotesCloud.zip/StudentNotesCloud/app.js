import app from "./firebase-config.js";

import {
    getAuth,
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    signOut
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

import {
    getFirestore,
    collection,
    addDoc,
    getDocs,
    query,
    orderBy
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";


const auth = getAuth(app);
const db = getFirestore(app);


// ==========================
// REGISTER
// ==========================

window.register = async function () {

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;

    if (email === "" || password === "") {
        alert("Enter email and password");
        return;
    }

    try {

        await createUserWithEmailAndPassword(
            auth,
            email,
            password
        );

        alert("Registration successful!");

        window.location.href = "index.html";

    } catch (error) {

        alert("Registration failed: " + error.message);

    }
};


// ==========================
// LOGIN
// ==========================

window.login = async function () {

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;

    if (email === "" || password === "") {
        alert("Enter email and password");
        return;
    }

    try {

        await signInWithEmailAndPassword(
            auth,
            email,
            password
        );

        alert("Login successful!");

        window.location.href = "dashboard.html";

    } catch (error) {

        alert("Login failed: " + error.message);

    }
};


// ==========================
// LOGOUT
// ==========================

window.logout = async function () {

    try {

        await signOut(auth);

        alert("Logged out successfully");

        window.location.href = "index.html";

    } catch (error) {

        alert(error.message);

    }
};


// ==========================
// GO REGISTER
// ==========================

window.goRegister = function () {

    window.location.href = "register.html";

};


// ==========================
// GO UPLOAD
// ==========================

window.goUpload = function () {

    window.location.href = "upload.html";

};


// ==========================
// SAVE NOTE
// ==========================

window.saveNote = async function () {

    const title =
        document.getElementById("noteTitle").value.trim();

    const subject =
        document.getElementById("subject").value.trim();

    const semester =
        document.getElementById("semester").value;

    const topic =
        document.getElementById("topic").value.trim();


    if (
        title === "" ||
        subject === "" ||
        semester === "" ||
        topic === ""
    ) {

        alert("Please fill all fields");

        return;
    }


    const user = auth.currentUser;


    if (!user) {

        alert("Please login first");

        window.location.href = "index.html";

        return;
    }


    try {

        await addDoc(collection(db, "notes"), {

            title: title,

            subject: subject,

            semester: semester,

            topic: topic,

            uploadedBy: user.email,

            createdAt: new Date()

        });


        alert("Note saved successfully!");

        document.getElementById("noteTitle").value = "";
        document.getElementById("subject").value = "";
        document.getElementById("topic").value = "";

        window.location.href = "dashboard.html";


    } catch (error) {

        alert("Error saving note: " + error.message);

    }

};


// ==========================
// VIEW NOTES
// ==========================

window.viewNotes = async function () {

    const notesArea =
        document.getElementById("notesArea");

    notesArea.innerHTML = "Loading notes...";


    try {

        const q = query(
            collection(db, "notes"),
            orderBy("createdAt", "desc")
        );

        const snapshot = await getDocs(q);


        notesArea.innerHTML = "";


        if (snapshot.empty) {

            notesArea.innerHTML = "<p>No notes found.</p>";

            return;
        }


        snapshot.forEach((doc) => {

            const note = doc.data();


            const div = document.createElement("div");

            div.className = "note";


            div.innerHTML = `

                <h3>${note.title}</h3>

                <p>
                    <b>Subject:</b>
                    ${note.subject}
                </p>

                <p>
                    <b>Semester:</b>
                    ${note.semester}
                </p>

                <p>
                    <b>Topic:</b>
                    ${note.topic}
                </p>

                <p>
                    <b>Uploaded by:</b>
                    ${note.uploadedBy}
                </p>

                <hr>

            `;


            notesArea.appendChild(div);

        });


    } catch (error) {

        notesArea.innerHTML =
            "Error loading notes: " + error.message;

    }

};