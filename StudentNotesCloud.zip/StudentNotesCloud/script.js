// ==========================================
// FIREBASE + GOOGLE DRIVE
// ==========================================

import app from "./firebase-config.js";

import {
    getAuth,
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    signOut
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

import {
    getFirestore,
    collection,
    addDoc,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";


// ==========================================
// FIREBASE SERVICES
// ==========================================

const auth = getAuth(app);
const db = getFirestore(app);


// ==========================================
// GOOGLE DRIVE SETTINGS
// ==========================================

// IMPORTANT:
// Replace this with your Google OAuth Web Client ID

const GOOGLE_CLIENT_ID =
    "PASTE_YOUR_GOOGLE_CLIENT_ID_HERE";


// Optional:
// If you have a particular Google Drive folder ID,
// paste it here.
// Otherwise leave it as "" and file will upload to Drive root.

const GOOGLE_DRIVE_FOLDER_ID = "";


// ==========================================
// GOOGLE DRIVE LOGIN TOKEN
// ==========================================

let accessToken = null;
let tokenClient = null;


// Load Google Identity Services automatically
function loadGoogleIdentityServices() {

    return new Promise((resolve, reject) => {

        if (window.google && window.google.accounts) {
            resolve();
            return;
        }

        const script = document.createElement("script");

        script.src =
            "https://accounts.google.com/gsi/client";

        script.onload = () => resolve();

        script.onerror = () =>
            reject(new Error("Google Identity Services failed to load."));

        document.head.appendChild(script);

    });
}


// Get Google Drive access
async function getDriveAccessToken() {

    await loadGoogleIdentityServices();

    return new Promise((resolve, reject) => {

        tokenClient =
            window.google.accounts.oauth2.initTokenClient({

                client_id: GOOGLE_CLIENT_ID,

                scope:
                    "https://www.googleapis.com/auth/drive.file",

                callback: (response) => {

                    if (response.error) {

                        console.error(
                            "Google OAuth Error:",
                            response
                        );

                        reject(response);

                        return;
                    }

                    accessToken = response.access_token;

                    resolve(accessToken);

                }

            });


        tokenClient.requestAccessToken();

    });
}


// ==========================================
// REGISTER
// ==========================================

window.register = function () {

    const email =
        document.getElementById("email").value.trim();

    const password =
        document.getElementById("password").value;


    if (email === "" || password === "") {

        alert("Please enter email and password.");

        return;
    }


    createUserWithEmailAndPassword(
        auth,
        email,
        password
    )

        .then((userCredential) => {

            console.log(
                "Registered User:",
                userCredential.user
            );

            alert("Registration successful!");

            // Optional login page
            window.location.href = "index.html";

        })

        .catch((error) => {

            console.error(
                "Registration Error:",
                error
            );

            alert(
                "Registration failed!\n\n" +
                error.code +
                "\n" +
                error.message
            );

        });

};


// ==========================================
// LOGIN
// ==========================================

window.login = function () {

    const email =
        document.getElementById("email").value.trim();

    const password =
        document.getElementById("password").value;


    if (email === "" || password === "") {

        alert("Please enter email and password.");

        return;
    }


    signInWithEmailAndPassword(
        auth,
        email,
        password
    )

        .then((userCredential) => {

            console.log(
                "Logged in User:",
                userCredential.user
            );

            alert("Login successful!");

            window.location.href =
                "dashboard.html";

        })

        .catch((error) => {

            console.error(
                "Login Error:",
                error
            );

            alert(
                "Login failed!\n\n" +
                error.code +
                "\n" +
                error.message
            );

        });

};


// ==========================================
// LOGOUT
// ==========================================

window.logout = function () {

    signOut(auth)

        .then(() => {

            alert("Logged out successfully!");

            window.location.href =
                "index.html";

        })

        .catch((error) => {

            console.error(
                "Logout Error:",
                error
            );

        });

};


// ==========================================
// DASHBOARD - UPLOAD NOTES PAGE
// ==========================================

window.uploadNotes = function () {

    window.location.href =
        "upload.html";

};


// ==========================================
// VIEW NOTES
// ==========================================

window.viewNotes = function () {

    alert(
        "My Notes feature will be added next."
    );

};


// ==========================================
// SEARCH NOTES
// ==========================================

window.searchNotes = function () {

    alert(
        "Search Notes feature will be added next."
    );

};


// ==========================================
// UPLOAD NOTE TO GOOGLE DRIVE
// ==========================================

window.uploadNote = async function () {

    const title =
        document.getElementById("noteTitle")
            .value.trim();

    const subject =
        document.getElementById("subject")
            .value.trim();

    const semester =
        document.getElementById("semester")
            .value;

    const topic =
        document.getElementById("topic")
            .value.trim();

    const fileInput =
        document.getElementById("noteFile");

    const status =
        document.getElementById("uploadStatus");


    // --------------------------------------
    // CHECK FILE
    // --------------------------------------

    const file =
        fileInput.files[0];


    if (
        title === "" ||
        subject === "" ||
        semester === "" ||
        topic === "" ||
        !file
    ) {

        alert(
            "Please fill all fields and select a file."
        );

        return;
    }


    try {

        status.innerText =
            "Connecting to Google Drive... ☁️";


        // --------------------------------------
        // CHECK FIREBASE LOGIN
        // --------------------------------------

        const user =
            auth.currentUser;


        if (!user) {

            alert(
                "Please login first."
            );

            window.location.href =
                "index.html";

            return;
        }


        // --------------------------------------
        // GOOGLE DRIVE ACCESS
        // --------------------------------------

        status.innerText =
            "Connecting to Google Drive...";


        const token =
            await getDriveAccessToken();


        // --------------------------------------
        // FILE METADATA
        // --------------------------------------

        const metadata = {

            name: file.name,

            mimeType: file.type ||
                "application/octet-stream"

        };


        // If folder ID is provided
        if (GOOGLE_DRIVE_FOLDER_ID !== "") {

            metadata.parents =
                [GOOGLE_DRIVE_FOLDER_ID];

        }


        // --------------------------------------
        // MULTIPART BODY
        // --------------------------------------

        const boundary =
            "-------StudentNotesBoundary";


        const delimiter =
            "\r\n--" +
            boundary +
            "\r\n";


        const closeDelimiter =
            "\r\n--" +
            boundary +
            "--";


        const multipartBody = new Blob([

            delimiter,

            "Content-Type: application/json; charset=UTF-8\r\n\r\n",

            JSON.stringify(metadata),

            delimiter,

            "Content-Type: " +
            (file.type ||
                "application/octet-stream") +
            "\r\n\r\n",

            file,

            closeDelimiter

        ]);


        // --------------------------------------
        // UPLOAD TO GOOGLE DRIVE
        // --------------------------------------

        status.innerText =
            "Uploading file to Google Drive... ☁️";


        const response =
            await fetch(

                "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,webViewLink",

                {

                    method: "POST",

                    headers: {

                        "Authorization":
                            "Bearer " + token,

                        "Content-Type":
                            "multipart/related; boundary=" +
                            boundary

                    },

                    body: multipartBody

                }

            );


        if (!response.ok) {

            const errorText =
                await response.text();

            console.error(
                "Google Drive Error:",
                errorText
            );

            throw new Error(
                "Google Drive upload failed: " +
                errorText
            );

        }


        const driveFile =
            await response.json();


        console.log(
            "Google Drive File:",
            driveFile
        );


        // --------------------------------------
        // CREATE DRIVE LINK
        // --------------------------------------

        const fileURL =
            driveFile.webViewLink ||
            "https://drive.google.com/file/d/" +
            driveFile.id +
            "/view";


        // --------------------------------------
        // SAVE DETAILS TO FIRESTORE
        // --------------------------------------

        status.innerText =
            "Saving note details...";


        await addDoc(

            collection(db, "notes"),

            {

                title: title,

                subject: subject,

                semester: semester,

                topic: topic,

                fileName: file.name,

                fileURL: fileURL,

                driveFileId: driveFile.id,

                uploadedBy: user.uid,

                uploaderEmail: user.email,

                uploadedAt:
                    serverTimestamp()

            }

        );


        // --------------------------------------
        // SUCCESS
        // --------------------------------------

        status.innerText =
            "✅ Note uploaded successfully!";


        alert(
            "Note uploaded successfully!\n\n" +
            "File saved in Google Drive."
        );


        // --------------------------------------
        // CLEAR FORM
        // --------------------------------------

        document.getElementById(
            "noteTitle"
        ).value = "";

        document.getElementById(
            "subject"
        ).value = "";

        document.getElementById(
            "semester"
        ).value = "";

        document.getElementById(
            "topic"
        ).value = "";

        document.getElementById(
            "noteFile"
        ).value = "";


    }

    catch (error) {

        console.error(
            "UPLOAD ERROR:",
            error
        );


        status.innerText =
            "❌ Upload failed";


        alert(
            "Upload failed!\n\n" +
            error.message
        );

    }

};


// ==========================================
// FIREBASE TEST
// ==========================================

console.log(
    "Firebase connected successfully!"
);

console.log(
    "Authentication ready!"
);

console.log(
    "Firestore ready!"
);

console.log(
    "Google Drive upload ready!"
);